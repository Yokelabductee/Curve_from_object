bl_info = {
    "name": "Curve from object",
    "author": "Yokelabductee",
    "description": "make a curve from keyframed object",
    "blender": (2, 93, 0),
    "version": (1, 0, 0),
    "category": "object"
}

import bpy
import addon_utils


def enable_addon(addon_module_name):
    loaded_default, loaded_state = addon.utils.check(addon_module_name)
    if not loaded_state:
        addon_utils.enable(addon_module_name)


# Add frame range properties to the Scene class
bpy.types.Scene.curve_from_object_start_frame = bpy.props.IntProperty(
    name="Start",
    description="The start frame for curve creation",
    default=1,
    min=1
)

bpy.types.Scene.curve_from_object_end_frame = bpy.props.IntProperty(
    name="End",
    description="The end frame for curve creation",
    default=100,
    min=1
)


# Define a new panel that includes the operator and frame range fields
class OBJECT_PT_my_panel(bpy.types.Panel):
    bl_idname = "OBJECT_PT_my_panel"
    bl_label = "C F O"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "C F O"

    def draw(self, context):
        layout = self.layout

        # Add frame range fields
        row = layout.row()
        row.prop(context.scene, "curve_from_object_start_frame")
        row.prop(context.scene, "curve_from_object_end_frame")

        # Add a button that runs the operator
        layout.operator("object.curve_from_object", text="Run C F O")


# Define a new operator that runs the script
class CurveFromObject(bpy.types.Operator):
    bl_idname = "object.curve_from_object"
    bl_label = "Curve_from_object"

    def execute(self, context):
        # Get the start and end frames from the panel properties
        start_frame = context.scene.curve_from_object_start_frame
        end_frame = context.scene.curve_from_object_end_frame

        # Set the frame range
        context.scene.frame_start = start_frame
        context.scene.frame_end = end_frame

        # Get the active object
        obj = bpy.context.active_object

        # Create an origin marker empty at the location of the active object
        origin_marker = bpy.data.objects.new("origin_marker", None)
        origin_marker.empty_display_size = 0.1
        origin_marker.empty_display_type = 'PLAIN_AXES'
        origin_marker.location = obj.location
        bpy.context.scene.collection.objects.link(origin_marker)

        # Create a new curve object
        curve = bpy.data.curves.new('curve', 'CURVE')
        curve.dimensions = '3D'
        spline = curve.splines.new('BEZIER')

        # Iterate through the frames
        for frame in range(bpy.context.scene.frame_start, bpy.context.scene.frame_end + 1):

            # Set the current frame
            bpy.context.scene.frame_set(frame)

            # Get the location of the empty at the current frame
            loc = obj.matrix_world.translation

            # Add a new point to the curve
            spline.bezier_points.add(1)
            point = spline.bezier_points[-1]
            point.co = loc
            point.handle_left_type = 'AUTO'
            point.handle_right_type = 'AUTO'

        # Create a new object from the curve
        curve_object = bpy.data.objects.new('curve_object', curve)
        bpy.context.scene.collection.objects.link(curve_object)

        # Go to frame 1
        bpy.context.scene.frame_set(1)

        # Set 3D cursor to origin of origin marker
        bpy.context.scene.cursor.location = origin_marker.location
        bpy.context.view_layer.objects.active = origin_marker

        # Make the curve the only active object and assign its origin to the 3D cursor
        bpy.ops.object.select_all(action='DESELECT')
        curve_object.select_set(True)
        bpy.context.view_layer.objects.active = curve_object
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        # Go to edit mode and delete the first control point
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.select_all(action='DESELECT')
        curve_object.data.splines.active.bezier_points[0].select_control_point = True
        bpy.ops.curve.delete(type='VERT')

        # Go back to object mode, deselect and delete the origin marker
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        origin_marker.select_set(True)
        bpy.ops.object.delete(use_global=False)
        return {'FINISHED'}

# Register the new classes with Blender
def register():
    bpy.utils.register_class(CurveFromObject)
    bpy.utils.register_class(OBJECT_PT_my_panel)

# Unregister the classes when the addon is disabled
def unregister():
    bpy.utils.unregister_class(CurveFromObject)
    bpy.utils.unregister_class(OBJECT_PT_my_panel)

# Only run the register function if this script is being run as an addon
if __name__ == "__main__":
    register()